// funkcje do operacji na plikach
#ifndef GK2024_PLIKI_H_INCLUDED
#define GK2024_PLIKI_H_INCLUDED

#include <stdio.h>
#include <math.h>
#include <fstream>
#include <SDL2/SDL.h>
#include <Windows.h>

#endif // GK2024_PLIKI_H_INCLUDED
void ladujG23(const char* nazwaPliku, int xPocz = 0, int yPocz = 0);
bool zapiszDoG23(const char* nazwaPliku, int tryb, bool dithering);
void G23DoBMP(const char* nazwaPliku);
std::string wczytajPlik_API();
std::string zapiszPlik_API(std::string rodzajPliku);
