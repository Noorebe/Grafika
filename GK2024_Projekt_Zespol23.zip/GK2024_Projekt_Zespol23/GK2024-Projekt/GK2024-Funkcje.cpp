// podstawowe funkcje
#include "GK2024-Funkcje.h"
#include "GK2024-Zmienne.h"
#include "GK2024-Paleta.h"
#include "GK2024-MedianCut.h"
#include "GK2024-Pliki.h"
/*
Funkcja ograniczająca wartość liczby do zakresu <0;255>
@param wartosc liczba do ograniczenia
@return ograniczona liczba
*/
Uint8 clamp8bit(float wartosc)
{
    if(wartosc > 255)
    {
        wartosc = 255;
    }else if(wartosc < 0)
    {
        wartosc = 0;
    }
    return wartosc;
}
/*
Funkcja oczekująca na akcję użytkownika.
*/
void idle()
{
    cout << "Press any key to continue...";
    SDL_Event event;
    while (SDL_WaitEvent(&event))
    {
        if(event.type == SDL_KEYDOWN) //czekaj na naciśnięcie jakiegokolwiek klawisza (pauza)
        {
            break;
        }
    }
    cout << endl; //wyczyszczenie buffora
}

/*
Konwersja koloru 24bit do 5 bit.
@return liczba 5 bitowa reprezentująca wejściowy kolor.
*/
Uint8 z24bitowNa5bitow(SDL_Color kolor) //odczytuje piksel i zamienia poszczególne składowe na liczbę 5bit w której bity odpowiadają kolejno: RRGGB
{
    int R, G, B;
    Uint8 kolor5bit;
    R = kolor.r;
    G = kolor.g;
    B = kolor.b;
    int newR = round(R*3.0/255.0);
    int newG = round(G*3.0/255.0);
    int newB = round(B*1.0/255.0);
    kolor5bit = (newR<<3) | (newG<<1) | newB;
    return kolor5bit;

}
/*
Konwersja koloru 24bit do odcieni szarości opisanych na 5 bitach.
@return liczba 5 bitowa reprezentująca wejściowy kolor w skali szarości.
*/
Uint8 z24bitowNa5bitowSzarosci(SDL_Color kolor)
{
    return (0.299*kolor.r + 0.587*kolor.g + 0.114*kolor.b) / 255 * 31;
}
/*
Konwersja koloru 5 bitowego na skalę 24 bitową.
@return kolor opisany przez liczbę wejściową.
*/
SDL_Color z5bitowNa24bity(Uint8 kolor) //konwertuje liczbę 5bit na obiekt klasy SDL_Color
{
    SDL_Color kolor24bit;
    int newR, newG, newB;
    newR = (kolor  & (0b00011000)) >> 3; //czerwony, (11000)
    newG = (kolor  & (0b00000110)) >> 1;    //zielony, (00110)
    newB = (kolor  & (0b00000001));         // niebieski, (00001)

    kolor24bit.r = newR * 255.0/3.0; //odtworzenie zakresu
    kolor24bit.g = newG * 255.0/3.0;
    kolor24bit.b = newB * 255.0/1.0;
    return kolor24bit;
}
/*
Konwersja koloru 5 bitowego w skali szarości na skalę 24 bitową.
@return kolor opisany przez liczbę wejściową.
*/
SDL_Color z5bitowNa24bitySzarosci(Uint8 kolor) //konwertuje liczbę 5bit na obiekt klasy SDL_Color, gdzie cała liczba opisuje jedynie odcienie szarości
{
    SDL_Color kolor24bit;
    Uint8 szary5bit = kolor / 32.0 * 255.0; //konwersja z 5bit na 8 bit
    kolor24bit.r = szary5bit;
    kolor24bit.g = szary5bit;
    kolor24bit.b = szary5bit;
    return kolor24bit;
}
/*
Funkcja sprawdzająca, czy wskazany kolor znajduje się w palecie dedykowanej.
@param kolor kolor wejściowy
@return index w tabeli paleta_dedykowana, pod którym znajduje się ten kolor
*/
int sprawdzKolor(SDL_Color kolor)
{
    if(ileKolorow > 0)
    {
        for(int i = 0; i < ileKolorow; i++)
        {
            if(porownajKolory(kolor, paleta_dedykowana[i]))
            {
                return i;
            }
        }
    }
    return dodajKolor(kolor);
}
/*
Funkcja porównująca 2 kolory.
@param kolor1 pierwszy kolor do porównania
@param kolor2 drugi kolor do porównania
@return true -> kolory są identyczne, false -> kolory są różne
*/
bool porownajKolory(SDL_Color kolor1, SDL_Color kolor2)
{
    if(kolor1.r != kolor2.r)
    {
        return false;
    }
    if(kolor1.g != kolor2.g)
    {
        return false;
    }
    if(kolor1.b != kolor2.b)
    {
        return false;
    }
    return true;
}
/*
    Funkcja dodająca wskazany kolor na koniec palety dedykowanej.
    @param kolor kolor do dodania
    @return index dodanego koloru w tablicy paleta_dedykowana
*/
int dodajKolor(SDL_Color kolor)
{
    int aktualnyKolor = ileKolorow;
    paleta_dedykowana[aktualnyKolor] = kolor;
    ileKolorow++;
    return aktualnyKolor;
}
/*
Funkcja konwertująca bazową tablicę bayera tak, aby operowała na zakresie 2bitów. (dla składowej czerwonej i zielonej)
*/
void zaktualizujTabliceBayera4_2bit()
{
    int zakresWartosci{85}; // 1/3 z 255 dla 2 bitow
    float zakres = zakresWartosci; //dla 2 bitów koloru R i G
    int rozmiar{4};
    float podzial = zakres*1.0/(rozmiar*rozmiar);
    for(int i = 0; i < rozmiar; i++)
    {
        for(int j = 0; j < rozmiar; j++)
        {
            zaktualizowanaTablicaBayera4[i][j] = (tablicaBayera4[i][j]*podzial)-podzial/2;
        }
    }
}
/*
Funkcja konwertująca bazową tablicę bayera tak, aby operowała na zakresie 5bitów. (dla skali szarości)
*/
void zaktualizujTabliceBayera4_5bit()
{
    int zakresWartosci{255};
    float zakres = zakresWartosci / 32.0; //dla 5 bitów szarych
    int rozmiar{4};
    float podzial = zakres*1.0/(rozmiar*rozmiar);
    for(int i = 0; i < rozmiar; i++)
    {
        for(int j = 0; j < rozmiar; j++)
        {
            zaktualizowanaTablicaBayera4[i][j] = (tablicaBayera4[i][j]*podzial)-podzial/2;
        }
    }
}
/*
Funkcja konwertująca bazową tablicę bayera tak, aby operowała na zakresie 1 bitu (dla składowej niebieskiej)
*/
void zaktualizujTabliceBayera4_1bit()
{
    int zakresWartosci{256};
    float zakres = zakresWartosci; //dla 1 bitu koloru B
    int rozmiar{4};
    float podzial = zakres*1.0/(rozmiar*rozmiar);
    for(int i = 0; i < rozmiar; i++)
    {
        for(int j = 0; j < rozmiar; j++)
        {
            zaktualizowanaTablicaBayera4_1[i][j] = (tablicaBayera4[i][j]*podzial)-podzial/2;
        }
    }
}
/*
Funkcja Konwertuje obraz na skalę szarości i konwertuje go na posiadaną paletę dedykowaną.
*/
void narysujZDedykowanejPaletySzarosci()
{
    SDL_Color kolor;
    Uint8 szary{};
    Uint8 index{};
    for(int y = 0; y < wysokosc / 2; y++)
    {
        for(int x = 0; x < szerokosc / 2; x++)
        {
            kolor=getPixel(x, y);
            szary = (0.299*kolor.r + 0.587*kolor.g + 0.114*kolor.b); //konwertuj na szary8bit
            index = znajdzSasiadaBW(szary); //znajdź najlepszy odpowiednik w palecie dedykowanej
            setPixel(x, y, paleta_dedykowana[index].r, paleta_dedykowana[index].g, paleta_dedykowana[index].b); //narysuj piksel o nowym kolorze
        }
    }
    narysujPalete(0, 200, paleta_dedykowana); //na koniec narysuj całą paletę
    SDL_UpdateWindowSurface(window);
}
/*
Funkcja Konwertuje obraz na skalę szarości i rysuje go wykorzystując paletę dedykowaną z wykorzystaniem ditheringu Floyda-Steinberga.
*/
void paletaDedykowanaSzarosciDithering()
{
    SDL_Color kolor;
    Uint8 szary;
    Uint8 szaryOrg;
    Uint8 przesuniecie{1};
    float bledy[(szerokosc/2)+2][wysokosc+2];
    memset(bledy, 0, sizeof(bledy));
    int blad{0};
        for(int y = 0; y < 200; y++)
    {
        for(int x = 0; x < 320; x++)
        {
            kolor = getPixel(x, y);
            szaryOrg = 0.299*kolor.r + 0.587*kolor.g+0.114*kolor.b;
            szary = clamp8bit(szaryOrg + bledy[x+przesuniecie][y]); //dodaj błąd
            int index = znajdzSasiadaBW(szary); //znajdź najlepszy kolor w palecie
            blad = szaryOrg - paleta_dedykowana[index].r; //oblicz jak duży błąd powstanie poprzez wykorzystanie tego koloru

            //aktualizuj tablicę błędów według algorytmu Floyda-Steinberga
            bledy[x+1+przesuniecie][y] += (blad*7.0/16.0);
            bledy[x-1+przesuniecie][y+1] += (blad*3.0/16.0);
            bledy[x+przesuniecie][y+1] += (blad*5.0/16.0);
            bledy[x+1+przesuniecie][y+1] += (blad*1.0/16.0);

            setPixel(x, y, paleta_dedykowana[index].r, paleta_dedykowana[index].r, paleta_dedykowana[index].r);
        }
    }
    narysujPalete(0, 200, paleta_dedykowana);
    SDL_UpdateWindowSurface(window);
}









void setPixel(int x, int y, Uint8 R, Uint8 G, Uint8 B)
{
  if ((x>=0) && (x<szerokosc) && (y>=0) && (y<wysokosc))
  {
    /* Zamieniamy poszczególne składowe koloru na format koloru piksela */
    Uint32 pixel = SDL_MapRGB(screen->format, R, G, B);

    /* Pobieramy informację ile bajtów zajmuje jeden piksel */
    int bpp = screen->format->BytesPerPixel;

    /* Obliczamy adres piksela */
    Uint8 *p1 = (Uint8 *)screen->pixels + (y*2) * screen->pitch + (x*2) * bpp;
    Uint8 *p2 = (Uint8 *)screen->pixels + (y*2+1) * screen->pitch + (x*2) * bpp;
    Uint8 *p3 = (Uint8 *)screen->pixels + (y*2) * screen->pitch + (x*2+1) * bpp;
    Uint8 *p4 = (Uint8 *)screen->pixels + (y*2+1) * screen->pitch + (x*2+1) * bpp;

    /* Ustawiamy wartość piksela, w zależnoœci od formatu powierzchni*/
    switch(bpp)
    {
        case 1: //8-bit
            *p1 = pixel;
            *p2 = pixel;
            *p3 = pixel;
            *p4 = pixel;
            break;

        case 2: //16-bit
            *(Uint16 *)p1 = pixel;
            *(Uint16 *)p2 = pixel;
            *(Uint16 *)p3 = pixel;
            *(Uint16 *)p4 = pixel;
            break;

        case 3: //24-bit
            if(SDL_BYTEORDER == SDL_BIG_ENDIAN) {
                p1[0] = (pixel >> 16) & 0xff;
                p1[1] = (pixel >> 8) & 0xff;
                p1[2] = pixel & 0xff;
                p2[0] = (pixel >> 16) & 0xff;
                p2[1] = (pixel >> 8) & 0xff;
                p2[2] = pixel & 0xff;
                p3[0] = (pixel >> 16) & 0xff;
                p3[1] = (pixel >> 8) & 0xff;
                p3[2] = pixel & 0xff;
                p4[0] = (pixel >> 16) & 0xff;
                p4[1] = (pixel >> 8) & 0xff;
                p4[2] = pixel & 0xff;
            } else {
                p1[0] = pixel & 0xff;
                p1[1] = (pixel >> 8) & 0xff;
                p1[2] = (pixel >> 16) & 0xff;
                p2[0] = pixel & 0xff;
                p2[1] = (pixel >> 8) & 0xff;
                p2[2] = (pixel >> 16) & 0xff;
                p3[0] = pixel & 0xff;
                p3[1] = (pixel >> 8) & 0xff;
                p3[2] = (pixel >> 16) & 0xff;
                p4[0] = pixel & 0xff;
                p4[1] = (pixel >> 8) & 0xff;
                p4[2] = (pixel >> 16) & 0xff;
            }
            break;

        case 4: //32-bit
            *(Uint32 *)p1 = pixel;
            *(Uint32 *)p2 = pixel;
            *(Uint32 *)p3 = pixel;
            *(Uint32 *)p4 = pixel;
            break;

        }
    }
}

void setPixelSurface(int x, int y, Uint8 R, Uint8 G, Uint8 B)
{
  if ((x>=0) && (x<szerokosc*2) && (y>=0) && (y<wysokosc*2))
  {
    /* Zamieniamy poszczególne składowe koloru na format koloru piksela */
    Uint32 pixel = SDL_MapRGB(screen->format, R, G, B);

    /* Pobieramy informację ile bajtów zajmuje jeden piksel */
    int bpp = screen->format->BytesPerPixel;

    /* Obliczamy adres piksela */
    Uint8 *p = (Uint8 *)screen->pixels + y * screen->pitch + x * bpp;

    /* Ustawiamy wartość piksela, w zależności od formatu powierzchni*/
    switch(bpp)
    {
        case 1: //8-bit
            *p = pixel;
            break;

        case 2: //16-bit
            *(Uint16 *)p = pixel;
            break;

        case 3: //24-bit
            if(SDL_BYTEORDER == SDL_BIG_ENDIAN) {
                p[0] = (pixel >> 16) & 0xff;
                p[1] = (pixel >> 8) & 0xff;
                p[2] = pixel & 0xff;
            } else {
                p[0] = pixel & 0xff;
                p[1] = (pixel >> 8) & 0xff;
                p[2] = (pixel >> 16) & 0xff;
            }
            break;

        case 4: //32-bit
            *(Uint32 *)p = pixel;
            break;
        }
    }
}

SDL_Color getPixel(int x, int y) {
    SDL_Color color ;
    Uint32 col = 0 ;
    if ((x>=0) && (x<szerokosc) && (y>=0) && (y<wysokosc)) {
        //określamy pozycję
        char* pPosition=(char*)screen->pixels ;

        //przesunięcie względem y
        pPosition+=(screen->pitch*y*2) ;

        //przesunięcie względem x
        pPosition+=(screen->format->BytesPerPixel*x*2);

        //kopiujemy dane piksela
        memcpy(&col, pPosition, screen->format->BytesPerPixel);

        //konwertujemy kolor
        SDL_GetRGB(col, screen->format, &color.r, &color.g, &color.b);
    }
    return ( color ) ;
}

SDL_Color getPixelSurface(int x, int y, SDL_Surface *surface) {
    SDL_Color color ;
    Uint32 col = 0 ;
    if ((x>=0) && (x<szerokosc) && (y>=0) && (y<wysokosc)) {
        //określamy pozycję
        char* pPosition=(char*)surface->pixels ;

        //przesunięcie względem y
        pPosition+=(surface->pitch*y) ;

        //przesunięcie względem x
        pPosition+=(surface->format->BytesPerPixel*x);

        //kopiujemy dane piksela
        memcpy(&col, pPosition, surface->format->BytesPerPixel);

        //konwertujemy kolor
        SDL_GetRGB(col, surface->format, &color.r, &color.g, &color.b);
    }
    return ( color ) ;
}


void ladujBMP(char const* nazwa, int x, int y) {
    SDL_Surface* bmp = SDL_LoadBMP(nazwa);
    if (!bmp)
    {
        printf("Unable to load bitmap: %s\n", SDL_GetError());
    }
    else
    {
        SDL_Color kolor;
        for (int yy=0; yy<bmp->h; yy++) {
			for (int xx=0; xx<bmp->w; xx++) {
				kolor = getPixelSurface(xx, yy, bmp);
				setPixel(xx, yy, kolor.r, kolor.g, kolor.b);
			}
        }
		SDL_FreeSurface(bmp);
        SDL_UpdateWindowSurface(window);
    }

}


void czyscEkran(Uint8 R, Uint8 G, Uint8 B)
{
    SDL_FillRect(screen, 0, SDL_MapRGB(screen->format, R, G, B));
    SDL_UpdateWindowSurface(window);
}
