// zmienne globalne
#ifndef GK2024_ZMIENNE_H_INCLUDED
#define GK2024_ZMIENNE_H_INCLUDED

#include <SDL2/SDL.h>
#include <fstream>
#define szerokosc 640
#define wysokosc 400

#define tytul "GK2024 - Projekt - Zespol 23"

extern SDL_Window* window;
extern SDL_Surface* screen;

extern SDL_Color paleta_dedykowana[32];
extern float paletaBledow[32];
extern int ileKolorow;
extern int nrIteracji;

extern SDL_Color paletaNarzucona5bit[32];
extern int tablicaBayera4[4][4];
extern float zaktualizowanaTablicaBayera4[4][4];
extern float zaktualizowanaTablicaBayera4_1[4][4];

extern std::ifstream plikOdczyt;
extern std::ofstream plikZapis;
//MedianCut
extern int ileKubelkow;
extern Uint8 obrazekSzarosc[320*200];
extern SDL_Color obraz[320*200];
#endif // GK2024_ZMIENNE_H_INCLUDED
