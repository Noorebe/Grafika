// funkcje do redukcji kolorów i tworzenia palet
#include "GK2024-Paleta.h"
#include "GK2024-Zmienne.h"
#include "GK2024-Funkcje.h"
#include "GK2024-MedianCut.h"
/*
Funkcja tworzy paletę narzuconą opisaną na 5 bitach i konwertuje wyświetlany obraz tak, aby jego kolory były opisane na 5 bitach.
@param xPocz współrzędna x górnego lewego rogu obrazu
@param yPocz współrzędna y górnego lewego rogu obrazu
*/
void paletaNarzucona(int xPocz, int yPocz)
{
    SDL_Color kolor, newColor;
    Uint8 kolor5bit;
    for(int y = 0; y < wysokosc / 2; y++)
    {
        for(int x = 0; x < szerokosc / 2; x++)
        {
            kolor=getPixel(x, y);
            kolor5bit = z24bitowNa5bitow(kolor); //przeskalowanie zakresu tak, aby zmieścił się w 5 bitach
            newColor = z5bitowNa24bity(kolor5bit); //powrót do 24 bitów w celu wyświetlenia na ekranie
            setPixel(x + xPocz, y + yPocz, newColor.r, newColor.g, newColor.b);
        }
    }
    for(int i = 0; i < 32; i++) //utworzenie palety narzuconej składającej się z 32 barw (5bitów)
    {
        paletaNarzucona5bit[i] = z5bitowNa24bity(i);
    }
    narysujPalete(0, 200, paletaNarzucona5bit); //wyświetlenie palety
    SDL_UpdateWindowSurface(window);
}
/*
Funkcja tworzy paletę narzuconą składającą się jedynie z odcieni szarości opisaną na 5 bitach i konwertuje wyświetlany obraz na odcienie szarości i opisuje je na 5 bitach.
@param xPocz współrzędna x górnego lewego rogu obrazu
@param yPocz współrzędna y górnego lewego rogu obrazu
*/
void paletaNarzuconaSzarosci(int xPocz, int yPocz)
{
    SDL_Color kolor, newColor;
    Uint8 szary5bit;
    for(int y = 0; y < wysokosc / 2; y++)
    {
        for(int x = 0; x < szerokosc / 2; x++)
        {
            kolor=getPixel(x, y); //pobierz piksel
            szary5bit = (0.299*kolor.r + 0.587*kolor.g + 0.114*kolor.b) / 255 * 31; //konwertuj na odcień szarości opisany na 5 bitach
            newColor = z5bitowNa24bitySzarosci(szary5bit); //powrót do 24 bitów w celu wyświetlenia na ekranie
            setPixel(x + xPocz, y + yPocz, newColor.r, newColor.g, newColor.b);
        }
    }
    SDL_UpdateWindowSurface(window);
    for(int i = 0; i < 32; i++) //utworzenie palety narzuconej składającej się z 32 odcieni szarości
    {
        paletaNarzucona5bit[i] = z5bitowNa24bitySzarosci(i);
    }
    narysujPalete(0, 200, paletaNarzucona5bit); //wyświetlenie palety
    SDL_UpdateWindowSurface(window);
}
/*
Funkcja rysuje wskazaną paletę 32 kolorów w podanym miejscu
@param poczX docelowa współrzędna x początku palety
@param poczY docelowa współrzędna y początku palety
@param paleta paleta do wyświetlenia
*/
void narysujPalete(int poczX, int poczY, SDL_Color paleta[])
{
    int x, y;

    for(int i = 0; i < 32; i++) //32 kolory dla 5 bitów
    {
        y = i / 8;
        x = i % 8;
        for(int row = 0; row < 40; row++) //tworzy grid 32 prostokątów, 4 rzędy po 8 kolumn o wymiarach 40x50 pikseli
        {
            for(int col = 0; col < 50; col++)
            {
                setPixel(x * 40 + row + poczX, y * 50 + col + poczY, paleta[i].r, paleta[i].g, paleta[i].b);
            }
        }
    }
}


/*
Funkcja zeruje wartości tablicy globalnej przechowującej informacje o palecie narzuconej obrazu.
*/
void czyscPalete()
{
    for(int i = 0; i < ileKolorow; i++)
    {
        paleta_dedykowana[i] = {0,0,0};
    }
    for(int i = 0; i < 32; i++)
    {
        paletaNarzucona5bit[i] = {0, 0, 0};
    }
    ileKolorow = 0;
}
/*
Funkcja analizuje obraz tworząc dedykowaną paletę kolorów na podstawie najczęściej występujących barw.
Dla obrazu skłądającego się z 32 lub mniej kolorów, program automatycznie stworzy paletę wykrytą zawierającą wszystkie kolory.
Dla obrazu o większej ilości kolorów, zastosowany zostanie algorytm medianCut w celu redukcji kolorów do 32.
*/
void paletaDedykowana()
{
    czyscPalete();
    SDL_Color kolor;
    for(int y = 0; y < wysokosc / 2; y++)
    {
        for(int x = 0; x < wysokosc / 2; x++)
        {
            kolor = getPixel(x, y);
            sprawdzKolor(kolor); //sprawdź czy kolor znajduje się już w palecie, jeśli nie, dodaje go
            if(ileKolorow > 32) //przerwij analize obrazu, paleta musi byc wygenerowana algorytmem Median Cut
            {
                break;
            }
        }
        if(ileKolorow > 32) //przerwij analize obrazu, paleta musi byc wygenerowana algorytmem Median Cut
        {
            break;
        }
    }
    if(ileKolorow <= 32) //obraz składa się z 32 lub mniej kolorów, można stworzyć paletę wykrytą
    {
        cout << "Paleta spełnia ograniczenia 5-bit -> generuje paletę wykrytą" << endl;
        narysujPalete(0, 200, paleta_dedykowana);
    }else
    {
        cout << "Paleta przekracza ograniczenia 5-bit -> generuje palete wykorzystujac algorytm Median Cut" << endl;
        paletaMedianCutKolor();
    }

    SDL_UpdateWindowSurface(window);
}
/*
Funkcja wykorzystuje dithering Floyda-Steinberga i rysuje obraz wejściowy na podstawie posiadanej palety dedykowanej.
*/
void paletaDedykowanaDithering()
{
    SDL_Color kolor;
    Uint8 R,G,B;
    Uint8 przesuniecie{1};
    float bledyR[(szerokosc/2)+2][wysokosc/2+2];
    float bledyG[(szerokosc/2)+2][wysokosc/2+2];
    float bledyB[(szerokosc/2)+2][wysokosc/2+2];
    memset(bledyR, 0, sizeof(bledyR));
    memset(bledyG, 0, sizeof(bledyG));
    memset(bledyB, 0, sizeof(bledyB));
    int bladR{0};
    int bladG{0};
    int bladB{0};
        for(int y = 0; y < 200; y++)
    {
        for(int x = 0; x < 320; x++)
        {
            kolor = getPixel(x, y);

            R = clamp8bit(kolor.r + bledyR[x+przesuniecie][y]);
            G = clamp8bit(kolor.g + bledyG[x+przesuniecie][y]);
            B = clamp8bit(kolor.b + bledyB[x+przesuniecie][y]);

            int index = znajdzSasiada({R,G,B});
            bladR = R - paleta_dedykowana[index].r;
            bladG = G - paleta_dedykowana[index].g;
            bladB = B - paleta_dedykowana[index].b;

            bledyR[x+1+przesuniecie][y] += (bladR*7.0/16.0);
            bledyR[x-1+przesuniecie][y+1] += (bladR*3.0/16.0);
            bledyR[x+przesuniecie][y+1] += (bladR*5.0/16.0);
            bledyR[x+1+przesuniecie][y+1] += (bladR*1.0/16.0);

            bledyG[x+1+przesuniecie][y] += (bladG*7.0/16.0);
            bledyG[x-1+przesuniecie][y+1] += (bladG*3.0/16.0);
            bledyG[x+przesuniecie][y+1] += (bladG*5.0/16.0);
            bledyG[x+1+przesuniecie][y+1] += (bladG*1.0/16.0);

            bledyB[x+1+przesuniecie][y] += (bladB*7.0/16.0);
            bledyB[x-1+przesuniecie][y+1] += (bladB*3.0/16.0);
            bledyB[x+przesuniecie][y+1] += (bladB*5.0/16.0);
            bledyB[x+1+przesuniecie][y+1] += (bladB*1.0/16.0);
            setPixel(x, y, paleta_dedykowana[index].r, paleta_dedykowana[index].g, paleta_dedykowana[index].b);
        }
    }
    narysujPalete(0, 200, paleta_dedykowana);
    SDL_UpdateWindowSurface(window);
}
/*
Funkcja wykorzystuje dithering na podstawie tablicy Bayera 4x4 do narysowania obrazu wejściowego.
*/
void paletaNarzuconaDitteringKolor()
{
    int rozmiarTablicy{4};
    constexpr float zakres = 255 / 3.0;
    int przesuniecieWartosci{0};
    zaktualizujTabliceBayera4_2bit();
    zaktualizujTabliceBayera4_1bit();
    SDL_Color kolor, newColor;
    Uint8 obecnyKolor[3]{};
    float wartoscWTablicy{};
    for(int y = 0; y < wysokosc / 2; y++)
    {
        for(int x = 0; x < szerokosc / 2; x++)
        {
            kolor=getPixel(x, y);
            newColor = kolor;
            wartoscWTablicy = zaktualizowanaTablicaBayera4[y%rozmiarTablicy][x%rozmiarTablicy];
            float wartoscWTablicy_1bit = zaktualizowanaTablicaBayera4_1[y%rozmiarTablicy][x%rozmiarTablicy];

            Uint8 obecnyKolor[3]{newColor.r, newColor.g, newColor.b};
            for(int skladowa = 0; skladowa < 2; skladowa++)
            {
                Uint8 wartoscSkladowej = obecnyKolor[skladowa];
                while(wartoscSkladowej > zakres)
                {
                    przesuniecieWartosci++;
                    wartoscSkladowej -= zakres;
                }
                if(wartoscSkladowej > wartoscWTablicy)
                {
                    obecnyKolor[skladowa] = 1;
                }else
                {
                    obecnyKolor[skladowa] = 0;
                }
                obecnyKolor[skladowa] += przesuniecieWartosci;
                obecnyKolor[skladowa] *= zakres;
                przesuniecieWartosci = 0;
            }
            if(obecnyKolor[2] > wartoscWTablicy_1bit)
                {
                    obecnyKolor[2] = 255;
                }else
                {
                    obecnyKolor[2] = 0;
                }
            newColor = {obecnyKolor[0], obecnyKolor[1], obecnyKolor[2]};
            setPixel(x, y, newColor.r, newColor.g, newColor.b);
        }
    }
    for(int i = 0; i < 32; i++)
    {
        paletaNarzucona5bit[i] = z5bitowNa24bity(i);
    }
    narysujPalete(0, 200, paletaNarzucona5bit);
    SDL_UpdateWindowSurface(window);
}
/*
Funkcja wykorzystuje dithering na podstawie tablicy Bayera 4x4 do narysowania obrazu wejściowego w odcieniach szarości.
*/
void paletaNarzuconaDitteringSzary()
{
    int rozmiarTablicy{4};
    constexpr float zakres = 255 / 32.0; //5bitów dla szarego
    int przesuniecieWartosci{0};
    zaktualizujTabliceBayera4_5bit();
    SDL_Color kolor, newColor;
    Uint8 szary5bit{};
    Uint8 szary8bit{};
    float nowySzary{};
    float wartoscWTablicy{};
    for(int y = 0; y < wysokosc / 2; y++)
    {
        for(int x = 0; x < szerokosc / 2; x++)
        {
            kolor=getPixel(x, y);
            szary8bit = (0.299*kolor.r + 0.587*kolor.g + 0.114*kolor.b); //konwertuj na szary8bit
            nowySzary = szary8bit;
            wartoscWTablicy = zaktualizowanaTablicaBayera4[y%rozmiarTablicy][x%rozmiarTablicy];
            while(nowySzary > zakres)
            {
                przesuniecieWartosci++;
                nowySzary -= zakres;
            }

            if(nowySzary > wartoscWTablicy)
            {
                szary5bit = 1;
            }else
            {
                szary5bit = 0;
            }
            szary5bit += przesuniecieWartosci;
            szary5bit *= zakres;
            przesuniecieWartosci = 0;
            newColor = z5bitowNa24bitySzarosci(szary5bit * 31.0 / 255);
            setPixel(x, y, newColor.r, newColor.g, newColor.b);
        }
    }
    for(int i = 0; i < 32; i++)
    {
        paletaNarzucona5bit[i] = z5bitowNa24bitySzarosci(i);
    }
    narysujPalete(0, 200, paletaNarzucona5bit);
    SDL_UpdateWindowSurface(window);
}
