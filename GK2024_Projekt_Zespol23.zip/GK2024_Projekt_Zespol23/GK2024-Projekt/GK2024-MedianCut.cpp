// metody do algorytmu kwantyzacji (MedianCut)
#include "GK2024-MedianCut.h"
#include "GK2024-Zmienne.h"
#include "GK2024-Funkcje.h"
#include "GK2024-Paleta.h"
using namespace std;

/*
Funkcja wykorzystuje algorytm Median Cut w celu znalezienia najbardziej uniwersalnych 32 odcieni szarości do opisania podanego obrazu.
Tworzy paletę dedykowaną ze znalezionych kolorów.
*/
void paletaMedianCutBW()
{
    cout << "Trwa działanie algorytmu Median Cut...\n";
    ileKubelkow = 0;
    ileKolorow = 0;
    czyscPalete();
    SDL_Color kolor;
    int szary{};
    int numer{};
    int index{};
    for(int y = 0; y < wysokosc / 2; y++)
    {
        for(int x = 0; x < szerokosc / 2; x++)
        {
            kolor=getPixel(x, y);
            szary = (0.299*kolor.r + 0.587*kolor.g + 0.114*kolor.b); //konwertuj na szary8bit
            obrazekSzarosc[numer] = szary;
            numer++;
        }
    }
    sortujKubelekBW(0, numer); //dla szarości sortujemy tylko 1 raz
    medianCutBW(0, numer - 1, 5); //5 iteracji dla 5 bitow, wykonuj rekurencyjnie

    narysujZDedykowanejPaletySzarosci();
}
/*
Rekurencyjna wersja funkcji realizująca algorytm Median Cut.
@param start początek obecnego kubełka
@param koniec koniec obecnego kubełka
@param iteracja ile jeszcze podziałów ma zostać wykonanych rekurencyjnie
*/
void medianCutBW(int start, int koniec, int iteracja)
{
    if(iteracja > 0) //dziel na pół, dopóki nie dojdziesz do ostatniej iteracji
    {
        int srodek = (start + koniec + 1) / 2;
        medianCutBW(start, srodek - 1, iteracja - 1);
        medianCutBW(srodek, koniec, iteracja - 1);
    }else //w ostatniej iteracji
    {
        int sumaBW{};
        for(int i = start; i <= koniec; i++)
        {
            sumaBW += obrazekSzarosc[i];
        }
        //uśrednij wartości wszystkich pikseli w kubełku i utwórz jeden odcień opisujący wszystkie te barwy
        Uint8 noweBW = sumaBW / (koniec + 1 - start);
        SDL_Color nowyKolor = {noweBW, noweBW, noweBW};
        paleta_dedykowana[ileKubelkow] = nowyKolor;
        ileKubelkow++;
    }
}
/*
Funkcja sortuje piksele obrazu tak, aby najbardziej podobne znalazły się obok siebie.
@param start początek sortowanej tablicy
@param koniec koniec sortowanej tablicy
*/
void sortujKubelekBW(int start, int koniec)
{
    int minimum{};
    for(int i = start; i <= koniec; i++)
    {
        minimum = i;
        for(int j = i; j <= koniec; j++)
        {
            if(obrazekSzarosc[j] < obrazekSzarosc[minimum])
            {
                minimum = j;
            }
        }
        swap(obrazekSzarosc[i], obrazekSzarosc[minimum]);
    }
}
/*
Funkcja określająca najbardziej podobny odcień szarości z palety dedykowanej do wskazanego koloru.
@param wartosc liczba 8 bitowa określająca pierwotny odcień
@return index w tablicy paleta_dedykowana określający najbardzie podobny kolor
*/
int znajdzSasiadaBW(Uint8 wartosc)
{
    int minimum{999};
    int indexMin{0};
    int odleglosc{};
    for(int i = 0; i < 32; i++) //5bit - 32 kolory
    {
        odleglosc = abs(wartosc - paleta_dedykowana[i].r);
        if(odleglosc < minimum)
        {
            minimum = odleglosc;
            indexMin = i;
        }
    }
    return indexMin;
}

/*
Funkcja wykorzystuje algorytm Median Cut w celu znalezienia najbardziej uniwersalnych 32 barw do opisania podanego obrazu.
Tworzy paletę dedykowaną ze znalezionych kolorów.
*/
void paletaMedianCutKolor()
{
    ileKubelkow = 0;
    ileKolorow = 0;
    czyscPalete();
    SDL_Color kolor;
    int numer{}; //index pierwszego wolnego miejsca w tablicy obraz
    int index{};
    for(int y = 0; y < wysokosc / 2; y++)
    {
        for(int x = 0; x < szerokosc / 2; x++)
        {
            kolor=getPixel(x, y);
            obraz[numer] = {kolor.r, kolor.g, kolor.b};
            numer++;
        }
    }
    cout << "Trwa działanie algorytmu Median Cut ukończono " << nrIteracji << "/32 etapów\n";
    nrIteracji++;
    sortujKubelek(0, numer, najwiekszaRoznica(0, numer)); //pierwsze sortowanie
    medianCutKolor(0, numer - 1, 5); //5 iteracji dla 5 bitow

    numer = 0;

    for(int y = 0; y < wysokosc / 2; y++)
    {
        for(int x = 0; x < szerokosc / 2; x++)
        {
            kolor = getPixel(x, y);
            index = znajdzSasiada(kolor); //znajduje najbardziej podobny kolor w tablicy wynikowej median Cut
            setPixel(x, y, paleta_dedykowana[index].r, paleta_dedykowana[index].g, paleta_dedykowana[index].b);
        }
    }
    narysujPalete(0, 200, paleta_dedykowana);
    SDL_UpdateWindowSurface(window);
}

/*
Rekurencyjna wersja funkcji realizująca algorytm Median Cut.
@param start początek obecnego kubełka
@param koniec koniec obecnego kubełka
@param iteracja ile jeszcze podziałów ma zostać wykonanych rekurencyjnie
*/
void medianCutKolor(int start, int koniec, int iteracja)
{
    if(iteracja > 0)
    {
        nrIteracji++;
        cout << "Trwa działanie algorytmu Median Cut ukończono " << nrIteracji << "/32 etapów\n";
        Uint8 sortowanie = najwiekszaRoznica(start, koniec); //znajduje składową, dla której w tym kubełku różnica między wartością największą i najmniejszą jest największa
        sortujKubelek(start, koniec, sortowanie); //sortuje kolory w kubełku na podstawie znalezionej składowej
        int srodek = (start + koniec + 1) / 2; //znajduje połowę kubełka, dzieląc go na 2 nowe
        medianCutKolor(start, srodek - 1, iteracja - 1); //wykonaj rekurencyjnie dla pierwszej połowy
        medianCutKolor(srodek, koniec, iteracja - 1); //wykonaj rekurencyjnie dla drugiej połowy
    }else //gdy wykonano wszystkie podziały, czyli podzielono na dokładnie 32 kubełki
    {
        int sumaR{};
        int sumaG{};
        int sumaB{};
        for(int i = start; i <= koniec; i++) //dla każdego koloru w kubełku oblicza średnią sum składowych tworząc uśredniony kolor reprezentujący wszystkie te kolory
        {
            sumaR += obraz[i].r;
            sumaG += obraz[i].g;
            sumaB += obraz[i].b;
        }
        int sredniaR = sumaR / (koniec + 1 - start);
        int sredniaG = sumaG / (koniec + 1 - start);
        int sredniaB = sumaB / (koniec + 1 - start);
        SDL_Color nowyKolor = {sredniaR, sredniaG, sredniaB};
        paleta_dedykowana[ileKubelkow] = nowyKolor; //zapisuje kolor do palety dedykowanej
        ileKubelkow++;
    }
}

/*
Funkcja znajduje składową, dla której rónica pomiędzy najmniejszą a największą wartością w podanym zakresie jest największa.
@param start początek tablicy obraz, w którym szukana jest różnica
@param koniec koniec tablicy obraz, w którym szukana jest różnica
@return 1 -> gdy rónica składowej R jest największa, 2 -> gdy rónica składowej G jest największa, 3 -> gdy rónica składowej B jest największa
*/
Uint8 najwiekszaRoznica(int start, int koniec)
{
    int minR = start;
    int minG = start;
    int minB = start;
    int maxR = start;
    int maxG = start;
    int maxB = start;
    Uint8 roznica{};
    for(int i = start; i <= koniec; i++)
    {
        if(obraz[i].r < obraz[minR].r)
        {
            minR = i;
        }
        if(obraz[i].g < obraz[minG].g)
        {
            minG = i;
        }
        if(obraz[i].b < obraz[minB].b)
        {
            minB = i;
        }
        if(obraz[i].r > obraz[maxR].r)
        {
            maxR = i;
        }
        if(obraz[i].g > obraz[maxG].g)
        {
            maxG = i;
        }
        if(obraz[i].b > obraz[maxB].b)
        {
            maxB = i;
        }
    }
    int roznicaR = obraz[maxR].r - obraz[minR].r;
    int roznicaG = obraz[maxG].g - obraz[minG].g;
    int roznicaB = obraz[maxB].b - obraz[minB].b;
    int rozmicaM = max(max(roznicaB, roznicaG), roznicaR);
    if(rozmicaM == roznicaR)
    {
        roznica = 1;
    }else if(rozmicaM == roznicaG)
    {
        roznica = 2;
    }else
    {
        roznica = 3;
    }
    return roznica;
}
/*
Funkcja sortująca tablicę obraz według wskazanego kanału.
@param start początek tablicy obraz, od którego zaczyna się sortowanie
@param koniec koniec tablicy obraz, na którym kończy się sortowanie
@param sortowanie kanał, według którego się sortuje 1-> R, 2-> G, 3-> B
*/
void sortujKubelek(int start, int koniec, Uint8 sortowanie)
{
    int minimum{};
    for(int i = start; i <= koniec; i++)
    {
        minimum = i;
        for(int j = i; j <= koniec; j++)
        {
            switch(sortowanie)
            {
            case 1:
                if(obraz[j].r < obraz[minimum].r)
                {
                    minimum = j;
                }
                break;
            case 2:
                if(obraz[j].g < obraz[minimum].g)
                {
                    minimum = j;
                }
                break;
            case 3:
                if(obraz[j].b < obraz[minimum].b)
                {
                    minimum = j;
                }
                break;
            }
        }
        swap(obraz[i], obraz[minimum]);
    }

}
/*
Funkcja określająca najbardziej podobny kolor z palety dedykowanej do wskazanego koloru.
@param kolor kolor wejściowy
@return index w tablicy paleta_dedykowana określający najbardzie podobny kolor
*/
int znajdzSasiada(SDL_Color kolor)
{
    int minimum{99999};
    int indexMin;
    SDL_Color kolorPaleta;
    float odleglosc;


    for(int i = 0; i < 32; i++) //5bit
    {
        kolorPaleta = paleta_dedykowana[i];
        odleglosc = sqrt((kolor.r - kolorPaleta.r)*(kolor.r - kolorPaleta.r) +
                         (kolor.g - kolorPaleta.g)*(kolor.g - kolorPaleta.g) +
                         (kolor.b - kolorPaleta.b)*(kolor.b - kolorPaleta.b));
        if(odleglosc < minimum)
        {
            minimum = odleglosc;
            indexMin = i;
        }
    }
    return indexMin;

}
