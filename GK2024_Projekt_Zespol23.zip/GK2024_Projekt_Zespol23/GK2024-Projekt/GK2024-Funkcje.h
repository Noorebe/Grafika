// podstawowe funkcje
#ifndef GK2024_FUNKCJE_H_INCLUDED
#define GK2024_FUNKCJE_H_INCLUDED

#include <stdio.h>
#include <math.h>
#include <SDL2/SDL.h>
Uint8 clamp8bit(float wartosc);
void idle();
int sprawdzKolor(SDL_Color kolor);
bool porownajKolory(SDL_Color kolor1, SDL_Color kolor2);
void zaktualizujTabliceBayera4_2bit();
void zaktualizujTabliceBayera4_5bit();
void zaktualizujTabliceBayera4_1bit();
int dodajKolor(SDL_Color kolor);
Uint8 z24bitowNa5bitow(SDL_Color kolor);
Uint8 z24bitowNa5bitowSzarosci(SDL_Color kolor);
SDL_Color z5bitowNa24bity(Uint8 kolor);
SDL_Color z5bitowNa24bitySzarosci(Uint8 kolor);
void setPixel(int x, int y, Uint8 R, Uint8 G, Uint8 B);
SDL_Color getPixel(int x, int y);
void czyscEkran(Uint8 R, Uint8 G, Uint8 B);
void ladujBMP(char const* nazwa, int x, int y);

void narysujZDedykowanejPaletySzarosci();
void paletaDedykowanaSzarosciDithering();
#endif // GK2024_FUNKCJE_H_INCLUDED
