// funkcje do operacji na plikach
#include "GK2024-Funkcje.h"
#include "GK2024-Zmienne.h"
#include "GK2024-Paleta.h"
#include "GK2024-MedianCut.h"
#include "GK2024-Pliki.h"
/*
Funkcja wykorzystująca windows API do otwierania plików.
@return ścieżka do wskazanego pliku
*/
std::string wczytajPlik_API()
{
    OPENFILENAME eksplorerPlikow;
    char maxPathSize[260] = {0};  // Bufor na ścieżkę pliku

    ZeroMemory(&eksplorerPlikow, sizeof(eksplorerPlikow));
    eksplorerPlikow.lStructSize = sizeof(eksplorerPlikow);
    eksplorerPlikow.hwndOwner = NULL;
    eksplorerPlikow.lpstrFile = maxPathSize;
    eksplorerPlikow.nMaxFile = sizeof(maxPathSize);
    eksplorerPlikow.lpstrFilter = "Pliki graficzne (*.bmp;*.png)\0*.bmp;*.g23\0Wszystko\0*.*\0\0"; //podpowiedzi rozszerzeń plików
    eksplorerPlikow.nFilterIndex = 1;
    eksplorerPlikow.lpstrFileTitle = NULL;
    eksplorerPlikow.nMaxFileTitle = 0;
    eksplorerPlikow.lpstrInitialDir = NULL;
    eksplorerPlikow.Flags = OFN_PATHMUSTEXIST | OFN_FILEMUSTEXIST;

    if (GetOpenFileName(&eksplorerPlikow))  // Otwórz okno dialogowe wyboru pliku
    {
        std::string filePath = maxPathSize;  // Konwersja ścieżki do string
        return filePath;
    }else //jeżeli zamknięto okno, zwróć pustą ścieżkę, nie wskazano żadnego pliku
    {
        return "";
    }
}
/*
Funkcja wykorzystująca windows API do zapisywania plików.
@param rodzajPliku rozszerzenie pliku, do jakiego chcemy zapisać, określa filtr wyświetlanych możliwości.
@return nazwa nowego pliku wraz ze ścieżką.
*/
std::string zapiszPlik_API(std::string rodzajPliku)
{
    OPENFILENAME eksplorerPlikow;
    char maxPathSize[260] = {0};  // Bufor na �cie�k� pliku

    ZeroMemory(&eksplorerPlikow, sizeof(eksplorerPlikow));
    eksplorerPlikow.lStructSize = sizeof(eksplorerPlikow);
    eksplorerPlikow.hwndOwner = NULL;
    eksplorerPlikow.lpstrFile = maxPathSize;
    eksplorerPlikow.nMaxFile = sizeof(maxPathSize);
    if(rodzajPliku == ".bmp") //dla plików bmp, podpowiadaj pliki bitmapy
    {
        eksplorerPlikow.lpstrFilter = "Bitmapy (*.bmp)\0*.bmp\0Wszystko\0*.*\0\0";
    }else if(rodzajPliku == ".g23") //dla plików g23, odfiltruj pliki bez tego rozszerzenia
    {
        eksplorerPlikow.lpstrFilter = "Grafika 5bit (*.g23)\0*.g23\0Wszystko\0*.*\0\0";
    }else
    {
        eksplorerPlikow.lpstrFilter = "Wszystko\0*.*\0\0";
    }
    eksplorerPlikow.nFilterIndex = 1;
    eksplorerPlikow.lpstrFileTitle = NULL;
    eksplorerPlikow.nMaxFileTitle = 0;
    eksplorerPlikow.lpstrInitialDir = NULL;
    eksplorerPlikow.Flags = OFN_PATHMUSTEXIST | OFN_FILEMUSTEXIST;

    if (GetSaveFileName(&eksplorerPlikow))  // Otwóż okno dialogowe wyboru pliku
    {
        std::string filePath = maxPathSize;  // Konwersja ścieżki do string
        return filePath;
    }else //jeżeli zamknięto okno, zwróć pustą ścieżkę, nie wskazano żadnego pliku
    {
        return "";
    }
}

/*
Funkcja pobierająca każdy piksel okna, zapisuje grafikę jako plik BMP.
@param nazwaPliku nazwa pliku, do którego ma zostać zapisana grafika.
*/
void G23DoBMP(const char* nazwaPliku)
{
    SDL_LockSurface(screen);
    SDL_SaveBMP(screen, nazwaPliku);
    SDL_UnlockSurface(screen);
}
/*
Funkcja odczytująca dane z wskazanego pliku, rysuje obraz na ekranie.
@param nazwaPliku nazwa pliku, do odczytu.
@param xPocz docelowa współrzędna x początku obrazu
@param yPocz docelowa współrzędna y początku obrazu
*/
void ladujG23(const char* nazwaPliku, int xPocz, int yPocz)
{
    SDL_Color kolor;
    Uint16 szerokoscObrazka{};
    Uint16 wysokoscObrazka{};
    Uint8 ileBitow{};
    Uint8 tryb{};
    Uint8 dithering{};
    char identyfikator[] = "   ";
    cout<<"Odczytywanie pliku "<< nazwaPliku << endl;
    plikOdczyt.open(nazwaPliku, ios::binary);
    plikOdczyt.read((char*)&identyfikator, sizeof(char)*3);
    plikOdczyt.read((char*)&szerokoscObrazka, sizeof(Uint16));
    plikOdczyt.read((char*)&wysokoscObrazka, sizeof(Uint16));
    plikOdczyt.read((char*)&ileBitow, sizeof (Uint8));
    plikOdczyt.read((char*)&tryb, sizeof (Uint8));
    plikOdczyt.read((char*)&dithering, sizeof (Uint8));
    cout<<"id: "<<identyfikator<<endl;
    cout<<"szerokosc: "<<szerokoscObrazka<<endl;
    cout<<"wysokosc: "<<wysokoscObrazka<<endl;
    cout<<"ile bitow: "<<(int)ileBitow<<endl;
    cout << "Tryb zapisu: ";
    switch(tryb)
    {
        case 1:
            cout << "Paleta narzucona";
            break;
        case 2:
            cout << "Paleta narzucona szarości";
            break;
        case 3:
            cout << "Paleta dedykowana";
            break;
        case 4:
            cout << "Paleta dedykowana szarości";
            break;
    }
    if(dithering > 0)
    {
        cout << " z użyciem ditheringu";
    }
    cout << "." << endl;

    if(tryb == 1 || tryb == 2) //bez palety, odczytuj obraz bezpośrednio
    {
        for (int y=0; y<wysokoscObrazka; y+= 8) //rzedami co 8 pixeli, czyli zerowy wiersz -> 8 wiersz -> 16 wiersz itd.
        {
            for (int x=0; x<szerokoscObrazka; x++)
            {
                Uint8 bajtyWejsciowe[5]{};
                Uint8 bajtyWyjsciowe[8]{};
                for(int przesuniecieY = 0; przesuniecieY < 5; przesuniecieY++)
                {
                    plikOdczyt.read((char*)&bajtyWejsciowe[przesuniecieY], sizeof(Uint8));
                }
                for (int i = 0; i < 5; i++)
                {
                    for (int j = 0; j < 8; j++)
                    {
                        bajtyWyjsciowe[j] |= ((bajtyWejsciowe[i] >> j) & 1) << i;
                    }
                }
                for(int i = 0; i < 8; i++)
                {
                    if(tryb == 1) //obraz kolorowy
                    {
                        kolor = z5bitowNa24bity(bajtyWyjsciowe[i]);
                    }else if(tryb == 2) //obraz szary
                    {
                        kolor = z5bitowNa24bitySzarosci(bajtyWyjsciowe[i]);
                    }

                    setPixel(x + xPocz, y + i + yPocz, kolor.r, kolor.g, kolor.b);
                }
            }
        }
    } else if(tryb == 3 || tryb == 4) //paleta dedykowana, odczytaj paletę
    {
        for(int i = 0; i < 32; i++) //odtwórz paletę dedykowaną
        {
            Uint8 R;
            Uint8 G;
            Uint8 B;

            plikOdczyt.read((char*)&R, sizeof(Uint8)); //zapisz wszystkie składowe każdego koloru do pliku
            plikOdczyt.read((char*)&G, sizeof(Uint8));
            plikOdczyt.read((char*)&B, sizeof(Uint8));
            paleta_dedykowana[i] = {R, G, B};
        }

        for (int y=0; y<wysokoscObrazka; y+= 8) //rzedami co 8 pixeli, czyli zerowy wiersz -> 8 wiersz -> 16 wiersz itd.
        {
            for (int x=0; x<szerokoscObrazka; x++)
            {
                Uint8 bajtyWejsciowe[5]{};
                Uint8 bajtyWyjsciowe[8]{};
                for(int przesuniecieY = 0; przesuniecieY < 5; przesuniecieY++)
                {
                    plikOdczyt.read((char*)&bajtyWejsciowe[przesuniecieY], sizeof(Uint8));
                }
                for (int i = 0; i < 5; i++)
                {
                    for (int j = 0; j < 8; j++)
                    {
                        bajtyWyjsciowe[j] |= ((bajtyWejsciowe[i] >> j) & 1) << i;
                    }
                }
                for(int i = 0; i < 8; i++)
                {
                    kolor = paleta_dedykowana[bajtyWyjsciowe[i]];
                    setPixel(x + xPocz, y + i + yPocz, kolor.r, kolor.g, kolor.b);
                }
            }
        }
    }
    plikOdczyt.close();
    SDL_UpdateWindowSurface (window);
}
/*
Funkcja pobiera obraz z ekranu i zapisuje go do pliku .g23.
@param nazwaPliku nazwa docelowego pliku do zapisu
@param tryb w jaki sposób nastąpiła konwersja obrazu (1->paleta narzucona, 2->paleta narzucona szarości, 3->paleta dedykowana, 4->paleta dedykowana szarości)
@param dithering 1->użyto ditheringu, 2-> nie użyto ditheringu
@return true dla udanej operacji zapisu
*/
bool zapiszDoG23(const char* nazwaPliku, int tryb, bool dithering)
{
    SDL_Color kolor;
    Uint16 szerokoscObrazka = szerokosc / 2;
    Uint16 wysokoscObrazka = wysokosc / 2;
    Uint8 kolor5bit;
    Uint8 bajtyWejsciowe[8]{};
    Uint8 ileBitow = 5;
    char identyfikator[] = "G23";
    Uint8 czyDithering;
    czyDithering = (dithering) ? 1 : 0;
    cout<<"Trwa zapisywanie pliku..."<<endl;
    plikZapis.open(nazwaPliku, ios::binary);
    plikZapis.write((char*)&identyfikator, sizeof(char)*3);
    plikZapis.write((char*)&szerokoscObrazka, sizeof(Uint16));
    plikZapis.write((char*)&wysokoscObrazka, sizeof(Uint16));
    plikZapis.write((char*)&ileBitow, sizeof(Uint8));
    plikZapis.write((char*)&tryb, sizeof(Uint8));
    plikZapis.write((char*)&czyDithering, sizeof(Uint8));
    if(tryb == 3 || tryb == 4) //tryb palety dedykowanej, zapisujemy całą wygenerowaną paletę do pliku
    {
        Uint8 indexWTablicy;
        for(int i = 0; i < 32; i++) //dla całej palety
        {
            Uint8 R = paleta_dedykowana[i].r;
            Uint8 G = paleta_dedykowana[i].g;
            Uint8 B = paleta_dedykowana[i].b;
            plikZapis.write((char*)&R, sizeof(Uint8)); //zapisz wszystkie składowe każdego koloru do pliku
            plikZapis.write((char*)&G, sizeof(Uint8));
            plikZapis.write((char*)&B, sizeof(Uint8));
        }

        for (int y = 0; y < wysokoscObrazka; y += 8) //rzedami co 8 pixeli, czyli zerowy wiersz -> 8 wiersz -> 16 wiersz itd.
        {
            for (int x = 0; x < szerokoscObrazka; x++)
            {
                for(int przesuniecieY = 0; przesuniecieY < 8; przesuniecieY++)
                {
                    indexWTablicy = znajdzSasiada(getPixel(x, y + przesuniecieY)); //znajduje index najbliższego koloru
                    bajtyWejsciowe[przesuniecieY] = indexWTablicy;
                }
                for (int i = 0; i < 5; i++)
                {
                    Uint8 bajtWyjsciowy{0};
                    for (int j = 0; j < 8; j++)
                    {
                        bajtWyjsciowy |= ((bajtyWejsciowe[j] >> i) & 1) << j;
                    }
                plikZapis.write((char*)&bajtWyjsciowy, sizeof(Uint8));
                }
            }
        }

    }

    for (int y=0; y<wysokoscObrazka; y+= 8) //rzedami co 8 pixeli, czyli zerowy wiersz -> 8 wiersz -> 16 wiersz itd.
    {
        for (int x=0; x<szerokoscObrazka; x++)
        {
            for(int przesuniecieY = 0; przesuniecieY < 8; przesuniecieY++)
            {
                kolor = getPixel(x, y + przesuniecieY);
                if(tryb == 1) //obraz kolorowy
                {
                    kolor5bit = z24bitowNa5bitow(kolor);
                }else if(tryb == 2) //obraz szary
                {
                    kolor5bit = z24bitowNa5bitowSzarosci(kolor);
                }
                bajtyWejsciowe[przesuniecieY] = kolor5bit;
            }
            for (int i = 0; i < 5; i++)
            {
                Uint8 bajtWyjsciowy{0};
                for (int j = 0; j < 8; j++)
                {
                    bajtWyjsciowy |= ((bajtyWejsciowe[j] >> i) & 1) << j;
                }
            plikZapis.write((char*)&bajtWyjsciowy, sizeof(Uint8));
            }
        }
    }
    plikZapis.close();
    return true;
    SDL_UpdateWindowSurface (window);
}

