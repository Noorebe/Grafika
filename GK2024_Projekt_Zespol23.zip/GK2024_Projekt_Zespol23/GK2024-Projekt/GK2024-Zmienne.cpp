// zmienne globalne
#include "GK2024-Zmienne.h"

SDL_Window* window = NULL;
SDL_Surface* screen = NULL;

SDL_Color paleta_dedykowana[32]; //tablica 32 kolor�w paley dedykowanej
int ileKolorow = 0; //ilo�� r�nych kolor�w znalezionych w obrazie

SDL_Color paletaNarzucona5bit[32];
//Lookup-table dla tablicy Bayera 4x4
int tablicaBayera4[4][4] = {{6, 14, 8, 16},
                            {10, 2, 12, 4},
                            {7, 15, 5, 13},
                            {11, 3, 9, 1}
                            };
float zaktualizowanaTablicaBayera4[4][4]{};
float zaktualizowanaTablicaBayera4_1[4][4]{};
float paletaBledow[32]{};
//MedianCut
int ileKubelkow = 0;
int nrIteracji = 0;
Uint8 obrazekSzarosc[320*200];
SDL_Color obraz[320*200];
//pliki
std::ifstream plikOdczyt;
std::ofstream plikZapis;
