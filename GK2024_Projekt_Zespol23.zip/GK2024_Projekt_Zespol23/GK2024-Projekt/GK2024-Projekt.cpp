// główny plik projektu
#include "GK2024-Zmienne.h"
#include "GK2024-Funkcje.h"
#include "GK2024-Paleta.h"
#include "GK2024-MedianCut.h"
#include "GK2024-Pliki.h"

#include <exception>
#include <string.h>
#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <SDL2/SDL.h>
#include <Windows.h>

#include <shobjidl.h>
#include<Commdlg.h>

using namespace std;


enum class stan{
WPROWADZANIE_SCIEZKI, //sekcja otwierania pliku
TWORZENIE_OKNA,
KONIEC_DZIALANIA, //zakończono wszystkie operacje, zamyka pliki i kończy program
PLIK_BMP, //sekcja obsługi plików BMP
PLIK_G23, //sekcja obsługi plików g23
IDLE, //oczekiwanie na input
ZAPIS_DO_G23 //sekcja zapisu do pliku
};



int main(int argc, char* argv[])
{
    if (SDL_Init(SDL_INIT_EVERYTHING) != 0)
    {
		printf("SDL_Init Error: %s\n", SDL_GetError());
		return EXIT_FAILURE;
    }

    SetConsoleOutputCP(CP_UTF8); //wyświetlanie polskich znaków przez konsolę
    stan stanProgramu = stan::WPROWADZANIE_SCIEZKI; //zmienna umożliwiająca swobodne zarządzanie stanem wykonywania programu
    string nazwaPliku{};
    string rozszerzenie{};
    int tryb{0}; //1 -> paleta narzucona, 2-> paleta narzucona szarości, 3-> paleta dedykowana, 4-> paleta dedykowana szarości
    bool czyUzycDitheringu{false};
    while(stanProgramu != stan::KONIEC_DZIALANIA)
    {
        switch(stanProgramu)
        {
            //----------------------------------------------------------------------------------------------------
            case stan::WPROWADZANIE_SCIEZKI:
            {
                cout<<"Wybierz plik do otwarcia. Obsługiwane typy plików:\n.bmp\n.g23\n";
                SDL_Delay(500); //daj czas użytkownikowi zanim wyświetli się okno dialogowe (0.5s)
                nazwaPliku = wczytajPlik_API();
                if(!plikOdczyt.good() || nazwaPliku.length() <= 4 || nazwaPliku == "") //błąd odczytu lub nie wskazano poprawnego pliku
                {
                    cout << "Nie udało się otworzyć pliku." << endl;
                    stanProgramu = stan::KONIEC_DZIALANIA;
                }else
                {
                    rozszerzenie = {nazwaPliku[nazwaPliku.length() - 4], nazwaPliku[nazwaPliku.length() - 3], nazwaPliku[nazwaPliku.length() - 2], nazwaPliku[nazwaPliku.length() - 1]};
                    stanProgramu = stan::TWORZENIE_OKNA;
                }
                break;
            }
            //----------------------------------------------------------------------------------------------------
            case stan::TWORZENIE_OKNA:
            {
                int mnoznikY{1};
                if(rozszerzenie == ".bmp") //dla plików bmp powiększ okno, aby umożliwić wyświetlenie nowej palety po konwersji
                {
                    mnoznikY = 2;
                }else if(rozszerzenie == ".g23")
                {
                    mnoznikY = 1;
                }
                window = SDL_CreateWindow(tytul, SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, szerokosc, wysokosc * mnoznikY, SDL_WINDOW_SHOWN);
                if (window == NULL)
                {
                    printf("SDL_CreateWindow Error: %s\n", SDL_GetError());
                    return EXIT_FAILURE;
                }

                screen = SDL_GetWindowSurface(window);
                if (screen == NULL)
                {
                    fprintf(stderr, "SDL_GetWindowSurface Error: %s\n", SDL_GetError());
                    return false;
                }
                SDL_UpdateWindowSurface(window);

                if(rozszerzenie == ".bmp") //obsługa plików bmp
                {
                    stanProgramu = stan::PLIK_BMP;
                }else if(rozszerzenie == ".g23") //obsługa plików g23
                {
                    stanProgramu = stan::PLIK_G23;
                }else //zamknięto okno bez wybrania pliku, nie ma rozszerzenia czyli nie da się otworzyć pliku
                {
                    cout << "Nie udało się otworzyć pliku.";
                    stanProgramu = stan::KONIEC_DZIALANIA;
                }
                break;
            }
            //----------------------------------------------------------------------------------------------------
            case stan::PLIK_G23:
            {
                ladujG23(nazwaPliku.c_str());
                idle(); //zatrzymaj program do naciśnięcia dowolnego klawisza
                SDL_MinimizeWindow(window); //ukryj okno aby zwrócić uwagę na dalsze etamy działania w konsoli
                SetForegroundWindow(GetConsoleWindow()); //wysuń konsolę na pierwszy plan
                string input;
                cout << "\nCzy wykonać konwersję do pliku .bmp? (y/n): ";
                cin >> input;
                cout << endl;
                bool czyBMP = (input == "y");
                if(czyBMP)
                {
                    string nazwaPliku = zapiszPlik_API(".bmp"); //wyświetl okno zapisu z podpowiedziami o rozrzerzeniu bmp
                    if(nazwaPliku == "") //nie wskazano żadnego pliku do zapisu (zamknięto okno)
                    {
                        cout << "Operacja niemożliwa.\n";
                        stanProgramu = stan::KONIEC_DZIALANIA;
                        break;
                    }
                    string rozszerzenie = {nazwaPliku[nazwaPliku.length() - 4], nazwaPliku[nazwaPliku.length() - 3], nazwaPliku[nazwaPliku.length() - 2], nazwaPliku[nazwaPliku.length() - 1]};
                    if(rozszerzenie != ".bmp") //użytkownik nie podał poprawnego rozszerzenia
                    {
                        nazwaPliku += ".bmp"; //dopisz prawidłowe rozrzerzenie
                    }
                    cout << "zapisywanie do '" << nazwaPliku << "'...";
                    G23DoBMP(nazwaPliku.c_str());
                    cout << "\nOperacja wykonana pomyślnie.\n";
                }
                stanProgramu = stan::KONIEC_DZIALANIA;
                break;
            }
            //----------------------------------------------------------------------------------------------------
            case stan::PLIK_BMP:
            {
                ladujBMP(nazwaPliku.c_str(), 0, 0);
                SDL_Delay(2000); //daj czas użytkownikowi zobaczyć obraz (2s)
                SDL_MinimizeWindow(window); //ukryj okno aby zwrócić uwagę na dalsze etamy działania w konsoli
                SetForegroundWindow(GetConsoleWindow()); //wysuń konsolę na pierwszy plan
                string input{"n"};
                cout << "\nWybierz tryb działania: \n";
                cout << "1 - Paleta narzucona" << endl;
                cout << "2 - Paleta narzucona szarości" << endl;
                cout << "3 - Paleta dedykowana" << endl;
                cout << "4 - Paleta dedykowana szarości" << endl;
                cin >> tryb;
                cout << "\nCzy użyć ditheringu? (y/n): ";
                cin >> input;
                cout << endl;
                czyUzycDitheringu = (input == "y");
                SDL_RestoreWindow(window);
                SDL_RaiseWindow(window);

                switch(tryb)
                {
                case 1: //PALETA_NARZUCONA
                    if(czyUzycDitheringu)
                    {
                        paletaNarzuconaDitteringKolor();
                    }else
                    {
                        paletaNarzucona();
                    }
                    break;
                case 2: //PALETA_NARZUCONA_SZAROSCI
                    if(czyUzycDitheringu)
                    {
                        paletaNarzuconaDitteringSzary();
                    }else
                    {
                        paletaNarzuconaSzarosci();
                    }
                    break;
                case 3: //PALETA_DEDYKOWANA
                    if(czyUzycDitheringu)
                    {
                        paletaDedykowana(); //tworzy paletę dedykowaną
                        ladujBMP(nazwaPliku.c_str(), 0, 0); //wczytuje ponownie obraz wejściowy przed zastosowaniem ditheringu
                        paletaDedykowanaDithering(); //wykonuje dithering z wykorzystaniem palety dedykowanej
                    }else
                    {
                        paletaDedykowana();
                    }
                    break;
                case 4: //PALETA_DEDYKOWANA_SZAROSCI
                    if(czyUzycDitheringu)
                    {
                        paletaMedianCutBW(); //tworzy paletę dedykowaną
                        ladujBMP(nazwaPliku.c_str(), 0, 0); //wczytuje ponownie obraz wejściowy przed zastosowaniem ditheringu
                        paletaDedykowanaSzarosciDithering(); //wykonuje dithering z wykorzystaniem palety dedykowanej
                    }else
                    {
                        paletaMedianCutBW();
                    }
                }
                stanProgramu = stan::ZAPIS_DO_G23; //po konwersji, przejdź do zapisu
                break;
            }
            //----------------------------------------------------------------------------------------------------
            case stan::ZAPIS_DO_G23:
            {
                idle();
                SDL_MinimizeWindow(window); //ukryj okno aby zwrócić uwagę na dalsze etamy działania w konsoli
                SetForegroundWindow(GetConsoleWindow()); //wysuń konsolę na pierwszy plan
                cout << "Czy chcesz zapisać wygenerowany plik?(y/n)  ";
                string input;
                cin >> input;
                cout << endl;
                if(input == "y")
                {
                    string nazwa = zapiszPlik_API(".g23");
                    string rozszerzenie = {nazwa[nazwa.length() - 4], nazwa[nazwa.length() - 3], nazwa[nazwa.length() - 2], nazwa[nazwa.length() - 1]};
                    if(rozszerzenie != ".g23")
                    {
                        nazwa += ".g23";
                    }
                    bool czySukces = zapiszDoG23(nazwa.c_str(), tryb, czyUzycDitheringu); //zapisz jako plik g23
                    if(!czySukces)
                    {
                        cout << "Błąd podczas zapisu pliku.\n";
                    }
                }
                stanProgramu = stan::KONIEC_DZIALANIA;
                break;
            }
            //----------------------------------------------------------------------------------------------------
            case stan::IDLE: //oczekiwanie na input, wykorzystywane aby dać czas użytkownikowi zobaczyć obraz
            {
                idle();
                stanProgramu = stan::KONIEC_DZIALANIA;
            }
            default: //dla każdego nieobsługiwanego stanu, zakończ działanie
            {
                stanProgramu = stan::KONIEC_DZIALANIA;
            }
        }
    }


    if(stanProgramu == stan::KONIEC_DZIALANIA)
    {
        cout << "kończenie pracy programu...\n" << endl;
        if (screen) //usuń obraz
        {
            SDL_FreeSurface(screen);
        }
        if (window) //usuń okno
        {
            SDL_DestroyWindow(window);
        }
        if(plikOdczyt.is_open()) //zamknij pliki
        {
            plikZapis.close();
        }
        if(plikZapis.is_open())
        {
            plikZapis.close();
        }
        SDL_Quit();
        system("pause");
        exit(0); //zamknij program
    }
    return 0;
}
